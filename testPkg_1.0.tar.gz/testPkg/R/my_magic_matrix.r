#' @title magic_matrix
#' 
#' @describeIn  return a magic matrix.
#' 
#' @details nothing.
#' 
#' @param name no input
#' 
#' @return a matrix
#' 
#' @export
#' @examples my_magic_matrix()



my_magic_matrix <- function(){
 mat <- matrix(c(4,9,2,3,5,7,8,1,6),3,3,byrow=TRUE)
 mat
}
